class Note {
  String name;
  String description;

  Note(this.name, this.description);
}

List<Note> list = [];
